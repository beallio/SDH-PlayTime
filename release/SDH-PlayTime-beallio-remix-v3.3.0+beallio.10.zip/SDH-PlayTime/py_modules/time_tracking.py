from datetime import datetime
from py_modules.db.dao import Dao
from py_modules.helpers import end_of_day
from py_modules.schemas.request import ApplyManualTimeCorrectionDict


class TimeTracking:
    __slots__ = ("dao",)
    dao: Dao

    def __init__(self, dao: Dao) -> None:
        self.dao = dao

    def add_time(self, started_at: int, ended_at: int, game_id: str, game_name: str):
        self.dao.save_game_dict(game_id, game_name)
        day_end_for_start_at = end_of_day(
            datetime.fromtimestamp(started_at)
        ).timestamp()

        intervals = []

        if started_at < day_end_for_start_at and ended_at > day_end_for_start_at:
            next_day_start = int(day_end_for_start_at + 1)
            intervals.append((started_at, next_day_start, game_id, game_name))
            intervals.append((next_day_start, ended_at, game_id, game_name))
        else:
            intervals.append((started_at, ended_at, game_id, game_name))

        for interval in intervals:
            (i_started_at, i_ended_at, i_game_id, _) = interval

            length = round(i_ended_at - i_started_at)

            self.dao.save_play_time(
                datetime.fromtimestamp(i_started_at), length, i_game_id
            )

    def apply_manual_time_for_games(
        self, list_of_game_stats: ApplyManualTimeCorrectionDict, source: str
    ):
        now = datetime.now()

        for stat in list_of_game_stats:
            self.dao.apply_manual_time_for_game(
                now, stat.game.id, stat.game.name, stat.time, source
            )
