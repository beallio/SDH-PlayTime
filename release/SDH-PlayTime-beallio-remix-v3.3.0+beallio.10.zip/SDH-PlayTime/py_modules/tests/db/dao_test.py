import sqlite3
from contextlib import closing
from datetime import datetime
from unittest.mock import patch

from py_modules.db.dao import Dao
from py_modules.db.migration import DbMigration
from py_modules.schemas.request import (
    AssociationComponentConfirmationRequest,
    AssociationComponentMember,
    MAX_ASSOCIATION_COMPONENT_MEMBERS,
)
from py_modules.schemas.response import AssociationComponentError
from py_modules.tests.helpers import AbstractDatabaseTest


class TestDao(AbstractDatabaseTest):
    dao: Dao

    def setUp(self) -> None:
        super().setUp()
        DbMigration(db=self.database).migrate()
        self.dao = Dao(db=self.database)

    def _create_checksum_star(self) -> None:
        for game_id, name in [
            ("alpha", "Alpha"),
            ("beta", "Beta"),
            ("gamma", "Gamma"),
        ]:
            self.dao.save_game_dict(game_id, name)
            self.dao.save_game_checksum(game_id, "shared", "SHA256", 1, None, None)
        self.dao.create_game_association("alpha", "beta")
        self.dao.create_game_association("alpha", "gamma")

    def _confirmation_request(
        self,
        snapshot,
        proposed_parent_game_id: str = "beta",
        selected_member_ids: tuple[str, ...] = ("alpha", "beta", "gamma"),
        fingerprint: str | None = None,
    ) -> AssociationComponentConfirmationRequest:
        return AssociationComponentConfirmationRequest(
            anchor_game_id=snapshot.anchor_game_id,
            proposed_parent_game_id=proposed_parent_game_id,
            proposed_parent_game_name=proposed_parent_game_id.title(),
            expected_parent_game_id=snapshot.expected_parent_game_id,
            expected_fingerprint=fingerprint or snapshot.fingerprint,
            selected_members=tuple(
                AssociationComponentMember(
                    game_id=game_id,
                    game_name=game_id.title(),
                )
                for game_id in selected_member_ids
            ),
        )

    def _create_oversized_checksum_component(self) -> tuple[str, ...]:
        member_ids = tuple(
            f"member-{index}" for index in range(MAX_ASSOCIATION_COMPONENT_MEMBERS + 1)
        )
        for game_id in member_ids:
            self.dao.save_game_dict(game_id, game_id.title())
            self.dao.save_game_checksum(game_id, "shared", "SHA256", 1, None, None)
        return member_ids

    def test_zero_time_identity_can_be_confirmed_as_parent_without_overall_time(
        self,
    ):
        self.dao.save_game_dict("tracked-child", "Tracked Child")
        self.dao.save_game_dict("zero-parent", "Zero Parent")

        zero_time_parent = self.dao.get_game("zero-parent")

        self.assertIsNotNone(zero_time_parent)
        self.assertEqual(zero_time_parent.time, 0)
        snapshot = self.dao.get_game_association_component("tracked-child")
        confirmation = self.dao.confirm_game_association_component(
            AssociationComponentConfirmationRequest(
                anchor_game_id=snapshot.anchor_game_id,
                proposed_parent_game_id="zero-parent",
                proposed_parent_game_name="Zero Parent",
                expected_parent_game_id=snapshot.expected_parent_game_id,
                expected_fingerprint=snapshot.fingerprint,
                selected_members=(
                    AssociationComponentMember("tracked-child", "Tracked Child"),
                    AssociationComponentMember("zero-parent", "Zero Parent"),
                ),
            )
        )

        self.assertEqual(confirmation.confirmed_parent.id, "zero-parent")
        self.assertEqual(
            {
                (association["parent_game_id"], association["child_game_id"])
                for association in self.dao.get_all_game_associations()
            },
            {("zero-parent", "tracked-child")},
        )

        refreshed_snapshot = self.dao.get_game_association_component("zero-parent")
        self.dao.confirm_game_association_component(
            AssociationComponentConfirmationRequest(
                anchor_game_id=refreshed_snapshot.anchor_game_id,
                proposed_parent_game_id="zero-parent",
                proposed_parent_game_name="Renamed Zero Parent",
                expected_parent_game_id=refreshed_snapshot.expected_parent_game_id,
                expected_fingerprint=refreshed_snapshot.fingerprint,
                selected_members=(
                    AssociationComponentMember("tracked-child", "Tracked Child"),
                    AssociationComponentMember("zero-parent", "Renamed Zero Parent"),
                ),
            )
        )

        with closing(sqlite3.connect(self.database_file)) as connection:
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM overall_time WHERE game_id = ?",
                    ("zero-parent",),
                ).fetchone(),
                (0,),
            )
            self.assertEqual(
                connection.execute(
                    "SELECT name, COUNT(*) FROM game_dict WHERE game_id = ?",
                    ("zero-parent",),
                ).fetchone(),
                ("Renamed Zero Parent", 1),
            )

    def test_confirmation_updates_nullable_zero_time_parent_name_without_overall_time(
        self,
    ):
        self.dao.save_game_dict("tracked-child", "Tracked Child")
        with closing(sqlite3.connect(self.database_file)) as connection:
            connection.execute(
                "INSERT INTO game_dict (game_id, name) VALUES (?, ?)",
                ("zero-parent", None),
            )
            connection.commit()

        snapshot = self.dao.get_game_association_component("tracked-child")
        confirmation = self.dao.confirm_game_association_component(
            AssociationComponentConfirmationRequest(
                anchor_game_id=snapshot.anchor_game_id,
                proposed_parent_game_id="zero-parent",
                proposed_parent_game_name="Selected Zero Parent",
                expected_parent_game_id=snapshot.expected_parent_game_id,
                expected_fingerprint=snapshot.fingerprint,
                selected_members=(
                    AssociationComponentMember("tracked-child", "Tracked Child"),
                    AssociationComponentMember("zero-parent", "Selected Zero Parent"),
                ),
            )
        )

        self.assertEqual(confirmation.confirmed_parent.name, "Selected Zero Parent")
        with closing(sqlite3.connect(self.database_file)) as connection:
            self.assertEqual(
                connection.execute(
                    "SELECT name, COUNT(*) FROM game_dict WHERE game_id = ?",
                    ("zero-parent",),
                ).fetchone(),
                ("Selected Zero Parent", 1),
            )
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM overall_time WHERE game_id = ?",
                    ("zero-parent",),
                ).fetchone(),
                (0,),
            )

    def test_grouped_association_read_has_sorted_members_and_fingerprint(self):
        self._create_checksum_star()

        snapshot = self.dao.get_game_association_component("gamma")

        self.assertEqual(snapshot.anchor_game_id, "gamma")
        self.assertEqual(
            tuple(member.id for member in snapshot.existing_members),
            ("alpha", "beta", "gamma"),
        )
        self.assertEqual(snapshot.expected_parent_game_id, "alpha")
        self.assertEqual(snapshot.status, "confirmed")
        self.assertEqual(snapshot.aliases, ("beta", "gamma"))
        self.assertEqual(
            snapshot.fingerprint,
            self.dao.game_association_component_fingerprint(("gamma", "alpha", "beta")),
        )

    def test_component_confirmation_is_idempotent_for_current_parent(self):
        self._create_checksum_star()
        self.dao.remove_game_association("gamma")
        snapshot = self.dao.get_game_association_component("beta")
        request = self._confirmation_request(snapshot, proposed_parent_game_id="alpha")

        result = self.dao.confirm_game_association_component(request)

        self.assertEqual(result.confirmed_parent.id, "alpha")
        self.assertEqual(result.status, "confirmed")
        self.assertEqual(
            {
                (association["parent_game_id"], association["child_game_id"])
                for association in self.dao.get_all_game_associations()
            },
            {("alpha", "beta"), ("alpha", "gamma")},
        )

    def test_component_confirmation_adds_new_selected_identity_to_star(self):
        self._create_checksum_star()
        snapshot = self.dao.get_game_association_component("beta")

        result = self.dao.confirm_game_association_component(
            self._confirmation_request(
                snapshot,
                proposed_parent_game_id="beta",
                selected_member_ids=("alpha", "beta", "gamma", "delta"),
            )
        )

        self.assertEqual(
            {
                (association["parent_game_id"], association["child_game_id"])
                for association in self.dao.get_all_game_associations()
            },
            {("beta", "alpha"), ("beta", "gamma"), ("beta", "delta")},
        )
        self.assertEqual(
            tuple(member.id for member in result.selected_members),
            ("alpha", "beta", "delta", "gamma"),
        )
        self.assertEqual(
            tuple(member.id for member in result.existing_members),
            ("alpha", "beta", "delta", "gamma"),
        )
        self.assertEqual(result.expected_parent_game_id, "beta")
        self.assertEqual(
            result.fingerprint,
            self.dao.game_association_component_fingerprint(
                ("alpha", "beta", "delta", "gamma")
            ),
        )
        self.assertEqual(result.aliases, ("alpha", "delta", "gamma"))
        with closing(sqlite3.connect(self.database_file)) as connection:
            self.assertEqual(
                connection.execute(
                    "SELECT name FROM game_dict WHERE game_id = ?", ("delta",)
                ).fetchone(),
                ("Delta",),
            )

    def test_oversized_persisted_component_rejects_before_name_lookup_or_mutation(
        self,
    ):
        member_ids = self._create_oversized_checksum_component()
        self.dao.create_game_association(member_ids[0], member_ids[1])
        before = self.dao.get_all_game_associations()
        request = AssociationComponentConfirmationRequest(
            anchor_game_id=member_ids[0],
            proposed_parent_game_id=member_ids[0],
            proposed_parent_game_name=member_ids[0].title(),
            expected_parent_game_id=None,
            expected_fingerprint=self.dao.game_association_component_fingerprint(
                member_ids
            ),
            selected_members=tuple(
                AssociationComponentMember(game_id, game_id.title())
                for game_id in member_ids[:MAX_ASSOCIATION_COMPONENT_MEMBERS]
            ),
        )

        with patch.object(
            self.dao, "_get_association_component_member_games"
        ) as get_member_games:
            with self.assertRaises(AssociationComponentError) as raised:
                self.dao.confirm_game_association_component(request)

        self.assertEqual(raised.exception.code, "INVALID_REQUEST")
        get_member_games.assert_not_called()
        self.assertEqual(self.dao.get_all_game_associations(), before)

    def test_component_confirmation_rejects_stale_fingerprint_without_writing(self):
        self._create_checksum_star()
        snapshot = self.dao.get_game_association_component("beta")
        before = self.dao.get_all_game_associations()

        with self.assertRaises(AssociationComponentError) as raised:
            self.dao.confirm_game_association_component(
                self._confirmation_request(snapshot, fingerprint="stale")
            )

        self.assertEqual(raised.exception.code, "STALE_COMPONENT")
        self.assertEqual(self.dao.get_all_game_associations(), before)

    def test_component_confirmation_rejects_member_owned_by_another_component(self):
        self._create_checksum_star()
        self.dao.save_game_dict("outsider", "Outsider")
        self.dao.save_game_dict("outsider-parent", "Outsider Parent")
        self.dao.create_game_association("outsider-parent", "outsider")
        snapshot = self.dao.get_game_association_component("beta")
        before = self.dao.get_all_game_associations()

        with self.assertRaises(AssociationComponentError) as raised:
            self.dao.confirm_game_association_component(
                self._confirmation_request(
                    snapshot,
                    selected_member_ids=("alpha", "beta", "gamma", "outsider"),
                )
            )

        self.assertEqual(raised.exception.code, "UNEXPECTED_MEMBER")
        self.assertEqual(self.dao.get_all_game_associations(), before)

    def test_component_confirmation_rejects_duplicate_or_invalid_new_members(self):
        self._create_checksum_star()
        snapshot = self.dao.get_game_association_component("beta")

        duplicate_request = self._confirmation_request(
            snapshot,
            selected_member_ids=("alpha", "beta", "gamma", "delta", "delta"),
        )
        invalid_name_request = AssociationComponentConfirmationRequest(
            anchor_game_id=snapshot.anchor_game_id,
            proposed_parent_game_id="alpha",
            proposed_parent_game_name="Alpha",
            expected_parent_game_id=snapshot.expected_parent_game_id,
            expected_fingerprint=snapshot.fingerprint,
            selected_members=(
                AssociationComponentMember("alpha", "Alpha"),
                AssociationComponentMember("beta", "Beta"),
                AssociationComponentMember("gamma", "Gamma"),
                AssociationComponentMember("delta", ""),
            ),
        )

        for request in (duplicate_request, invalid_name_request):
            with self.assertRaises(AssociationComponentError) as raised:
                self.dao.confirm_game_association_component(request)

            self.assertEqual(raised.exception.code, "INVALID_REQUEST")

    def test_component_confirmation_rolls_back_when_star_reinsertion_fails(self):
        self._create_checksum_star()
        snapshot = self.dao.get_game_association_component("beta")
        before = self.dao.get_all_game_associations()
        original_create = self.dao._create_game_association
        calls = 0

        def fail_second_insert(connection, parent_game_id, child_game_id):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise RuntimeError("injected insertion failure")
            original_create(connection, parent_game_id, child_game_id)

        with patch.object(self.dao, "_create_game_association", fail_second_insert):
            with self.assertRaises(AssociationComponentError) as raised:
                self.dao.confirm_game_association_component(
                    self._confirmation_request(
                        snapshot,
                        proposed_parent_game_id="beta",
                        selected_member_ids=("alpha", "beta", "gamma", "delta"),
                    )
                )

        self.assertEqual(raised.exception.code, "ASSOCIATION_UPDATE_FAILED")
        self.assertEqual(self.dao.get_all_game_associations(), before)
        with closing(sqlite3.connect(self.database_file)) as connection:
            self.assertIsNone(
                connection.execute(
                    "SELECT name FROM game_dict WHERE game_id = ?", ("delta",)
                ).fetchone()
            )

    def test_component_confirmation_rejects_invalid_bounded_input_before_component_read(
        self,
    ):
        self._create_checksum_star()
        snapshot = self.dao.get_game_association_component("beta")
        oversized_members_request = self._confirmation_request(
            snapshot,
            selected_member_ids=tuple(f"member-{index}" for index in range(101)),
        )
        oversized_name_request = AssociationComponentConfirmationRequest(
            anchor_game_id=snapshot.anchor_game_id,
            proposed_parent_game_id="alpha",
            proposed_parent_game_name="N" * 1025,
            expected_parent_game_id=snapshot.expected_parent_game_id,
            expected_fingerprint=snapshot.fingerprint,
            selected_members=(
                AssociationComponentMember("alpha", "Alpha"),
                AssociationComponentMember("beta", "Beta"),
                AssociationComponentMember("gamma", "Gamma"),
            ),
        )

        for request in (oversized_members_request, oversized_name_request):
            with patch.object(self.dao, "_get_game_association_component") as read:
                with self.assertRaises(AssociationComponentError) as raised:
                    self.dao.confirm_game_association_component(request)

            self.assertEqual(raised.exception.code, "INVALID_REQUEST")
            read.assert_not_called()

    def test_identity_components_select_an_explicit_parent_across_a_transitive_checksum_family(
        self,
    ):
        for game_id, name in [
            ("checksum-leader", "Checksum Leader"),
            ("bridge", "Bridge"),
            ("child", "Child"),
            ("explicit-parent", "Explicit Parent"),
        ]:
            self.dao.save_game_dict(game_id, name)

        self.dao.save_play_time(datetime(2025, 1, 1, 10, 0), 30, "checksum-leader")
        self.dao.save_play_time(datetime(2025, 1, 2, 10, 0), 70, "child")
        for game_id, checksum in [
            ("checksum-leader", "left"),
            ("bridge", "left"),
            ("bridge", "right"),
            ("child", "right"),
        ]:
            self.dao.save_game_checksum(game_id, checksum, "SHA256", 1, None, None)
        self.dao.create_game_association("explicit-parent", "child")

        all_time = self.dao.fetch_playtime_information()
        period = self.dao.fetch_playtime_information_for_period(
            datetime(2025, 1, 1), datetime(2025, 1, 3)
        )

        expected_aliases = "bridge,checksum-leader,child"
        self.assertEqual(len(all_time), 1)
        self.assertEqual(all_time[0].game_id, "explicit-parent")
        self.assertEqual(all_time[0].game_name, "Explicit Parent")
        self.assertEqual(all_time[0].total_time, 100)
        self.assertEqual(all_time[0].aliases_id, expected_aliases)
        self.assertEqual(len(period), 1)
        self.assertEqual(period[0].game_id, "explicit-parent")
        self.assertEqual(period[0].total_time, 100)
        self.assertEqual(period[0].aliases_id, expected_aliases)

    def test_conflicting_explicit_parents_use_a_fallback_without_writing_associations(
        self,
    ):
        for game_id in ["alpha", "beta", "parent-a", "parent-b"]:
            self.dao.save_game_dict(game_id, game_id)
        for game_id in ["alpha", "beta"]:
            self.dao.save_game_checksum(game_id, "shared", "SHA256", 1, None, None)
        self.dao.create_game_association("parent-a", "alpha")
        self.dao.create_game_association("parent-b", "beta")
        before = self.dao.get_all_game_associations()

        components = self.dao.get_game_identity_components()
        report = self.dao.fetch_playtime_information()

        component = components["parent-a"]
        self.assertEqual(component.status, "conflict")
        self.assertEqual(component.canonical_id, "alpha")
        self.assertEqual(component.explicit_parent_ids, ("parent-a", "parent-b"))
        self.assertEqual(report[0].game_id, "alpha")
        self.assertEqual(report[0].aliases_id, "beta,parent-a,parent-b")
        self.assertEqual(self.dao.get_all_game_associations(), before)

    def test_should_save_game_dict_only_once(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_game_dict("1001", "Zelda BOTW - updated")

        with closing(sqlite3.connect(self.database_file)) as connection:
            result = connection.execute(
                "select game_id, name from game_dict"
            ).fetchone()
        self.assertEqual(result[0], "1001")
        self.assertEqual(result[1], "Zelda BOTW - updated")

    def test_should_add_new_interval(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2023, 1, 1, 10, 0), 3600, "1001")
        with closing(sqlite3.connect(self.database_file)) as connection:
            result = connection.execute(
                "select date_time, game_id, duration from play_time"
            ).fetchone()
        self.assertEqual(result[0], "2023-01-01T10:00:00")
        self.assertEqual(result[1], "1001")
        self.assertEqual(result[2], 3600)

    def test_should_calculate_per_day_time_report(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_game_dict("1002", "DOOM")
        self.dao.save_play_time(datetime(2023, 1, 1, 9, 0), 3600, "1001")
        self.dao.save_play_time(datetime(2023, 1, 1, 11, 0), 1800, "1001")
        self.dao.save_play_time(datetime(2023, 1, 2, 10, 0), 2000, "1002")
        result = self.dao.fetch_per_day_time_report(
            datetime(2023, 1, 1, 0, 0), datetime(2023, 1, 2, 23, 59)
        )
        self.assertEqual(len(result), 2)

        self.assertEqual(result[0].date, "2023-01-01")
        self.assertEqual(result[0].game_id, "1001")
        self.assertEqual(result[0].game_name, "Zelda BOTW")
        self.assertEqual(result[0].time, 5400)

        self.assertEqual(result[1].date, "2023-01-02")
        self.assertEqual(result[1].game_id, "1002")
        self.assertEqual(result[1].game_name, "DOOM")
        self.assertEqual(result[1].time, 2000)

    def test_should_calculate_per_day_time_report_with_game_id(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_game_dict("1002", "DOOM")
        self.dao.save_play_time(datetime(2023, 1, 1, 9, 0), 3600, "1001")
        self.dao.save_play_time(datetime(2023, 1, 1, 11, 0), 1800, "1001")
        self.dao.save_play_time(datetime(2023, 1, 2, 10, 0), 2000, "1002")

        result = self.dao.fetch_per_day_time_report(
            datetime(2023, 1, 1, 0, 0), datetime(2023, 1, 2, 23, 59), "1001"
        )

        self.assertEqual(len(result), 1)

        self.assertEqual(result[0].date, "2023-01-01")
        self.assertEqual(result[0].game_id, "1001")
        self.assertEqual(result[0].game_name, "Zelda BOTW")
        self.assertEqual(result[0].time, 5400)

    def test_should_manually_added_playtime_for_tracked_game(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2023, 1, 1, 11, 0), 1800, "1001")
        self.dao.apply_manual_time_for_game(
            create_at=datetime.now(),
            game_id="1001",
            game_name="Zelda BOTW",
            new_overall_time=3600,
            source="manually-added_time",
        )

        self.assertEqual(self._get_overall_time_for_game("1001"), 3600)

    def test_should_manually_added_playtime_for_not_tracked_game(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.apply_manual_time_for_game(
            create_at=datetime.now(),
            game_id="1001",
            game_name="Zelda BOTW",
            new_overall_time=3600,
            source="manually-added-time",
        )

        self.assertEqual(self._get_overall_time_for_game("1001"), 3600)

    def test_should_have_date_before(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2023, 1, 1), 3600, "1001")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 5))

        self.assertEqual(has_data_before, True)

    def test_should_have_date_before_with_game_id(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2023, 1, 1), 3600, "1001")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1), "1001")

        self.assertEqual(has_data_before, True)

    def test_should_not_have_date_before(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 1, 1), 3600, "1001")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1))

        self.assertEqual(has_data_before, False)

    def test_should_not_have_date_before_with_game_id(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 1, 1), 3600, "1001")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1), "1001")

        self.assertEqual(has_data_before, False)

    def test_should_have_date_after(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 1, 1, 9, 0), 3600, "1001")

        has_data_after = self.dao.has_data_after(datetime(2023, 1, 1))

        self.assertEqual(has_data_after, True)

    def test_should_not_have_date_after_with_game_id(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 1, 1), 3600, "1001")

        has_data_after = self.dao.has_data_after(datetime(2025, 5, 1), "1001")

        self.assertEqual(has_data_after, False)

    def test_should_not_have_date_after_when_no_data_exists(self):
        has_data_after = self.dao.has_data_after(datetime(2025, 5, 1))

        self.assertEqual(has_data_after, False)

    def test_should_have_multiple_dates_before(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2023, 1, 1), 3600, "1001")
        self.dao.save_play_time(datetime(2024, 1, 1), 7200, "1001")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1))

        self.assertEqual(has_data_before, True)

    def test_should_have_data_before_with_multiple_games(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2023, 1, 1), 3600, "1001")

        self.dao.save_game_dict("1002", "Mario Kart")
        self.dao.save_play_time(datetime(2024, 1, 1), 1800, "1002")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1))

        self.assertEqual(has_data_before, True)

    def test_should_have_data_after_with_multiple_games(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 1, 1), 3600, "1001")

        self.dao.save_game_dict("1002", "Mario Kart")
        self.dao.save_play_time(datetime(2025, 5, 1), 7200, "1002")

        has_data_after = self.dao.has_data_after(datetime(2025, 1, 1))

        self.assertEqual(has_data_after, True)

    def test_should_not_have_data_after_for_specific_game(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 1, 1), 3600, "1001")

        self.dao.save_game_dict("1002", "Mario Kart")
        self.dao.save_play_time(datetime(2025, 5, 1), 7200, "1002")

        has_data_after = self.dao.has_data_after(
            datetime(2025, 1, 1, 23, 59, 59), "1001"
        )

        self.assertEqual(has_data_after, False)

    def test_should_not_have_data_after_when_no_playtime_exists(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")

        has_data_after = self.dao.has_data_after(datetime(2025, 1, 1))

        self.assertEqual(has_data_after, False)

    def test_should_not_have_date_before_when_all_data_is_after(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 1, 1), 3600, "1001")
        self.dao.save_play_time(datetime(2025, 6, 1), 7200, "1001")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1))

        self.assertEqual(has_data_before, False)

    def test_should_have_data_before_when_no_playtime_exists_for_game(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1), "1001")

        self.assertEqual(has_data_before, False)

    def test_should_not_have_date_before_when_equal_to_saved_playtime(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 1, 1), 3600, "1001")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1))

        self.assertEqual(has_data_before, False)

    def test_should_have_data_after_for_current_date(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2025, 7, 10), 3600, "1001")

        has_data_after = self.dao.has_data_after(datetime(2025, 7, 9))

        self.assertEqual(has_data_after, True)

    def test_should_have_data_before_after_with_zero_duration(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_play_time(datetime(2023, 1, 1), 0, "1001")

        has_data_before = self.dao.has_data_before(datetime(2025, 1, 1))
        has_data_after = self.dao.has_data_after(datetime(2022, 1, 1))

        self.assertEqual(has_data_before, True)
        self.assertEqual(has_data_after, True)

    def test_should_save_game_checksum(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_game_checksum(
            "1001",
            "10c28f0e7cd1917b2f595828df",
            "SHA256",
            16 * 1024 * 1024,
            None,
            None,
        )
        self.dao.save_game_checksum(
            "1001",
            "10c28f0e7cd1917b2f595828df12312",
            "SHA256",
            16 * 1024 * 1024,
            None,
            None,
        )
        result = self.dao.get_game_files_checksum("1001")

        self.assertEqual(len(result), 2)

    def test_should_remove_game_checksum(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_game_checksum(
            "1001",
            "10c28f0e7cd1917b2f595828df",
            "SHA256",
            16 * 1024 * 1024,
            None,
            None,
        )
        self.dao.save_game_checksum(
            "1001",
            "10c28f0e7cd1917b2f595828df12312",
            "SHA256",
            16 * 1024 * 1024,
            None,
            None,
        )

        self.dao.remove_game_checksum("1001", "10c28f0e7cd1917b2f595828df12312")

        result = self.dao.get_game_files_checksum("1001")

        self.assertEqual(len(result), 1)

    def test_should_remove_all_game_checksums(self):
        self.dao.save_game_dict("1001", "Zelda BOTW")
        self.dao.save_game_checksum(
            "1001",
            "10c28f0e7cd1917b2f595828df",
            "SHA256",
            16 * 1024 * 1024,
            None,
            None,
        )
        self.dao.save_game_checksum(
            "1001",
            "10c28f0e7cd1917b2f595828df12312",
            "SHA256",
            16 * 1024 * 1024,
            None,
            None,
        )

        self.dao.remove_all_game_checksums("1001")

        result = self.dao.get_game_files_checksum("1001")

        self.assertEqual(len(result), 0)

    def test_link_game_to_game_with_checksum_copies_checksum(self):
        self.dao.save_game_dict("parent_game", "Parent Game")
        self.dao.save_game_dict("alias_game", "Parent Game")  # Child must exist
        self.dao.save_game_checksum(
            "parent_game",
            "abc123def456",
            "SHA256",
            16 * 1024 * 1024,
            None,
            None,
        )

        self.dao.link_game_to_game_with_checksum("alias_game", "parent_game")

        checksums = self.dao.get_game_files_checksum("alias_game")
        self.assertEqual(len(checksums), 1)
        self.assertEqual(checksums[0].checksum, "abc123def456")

    def test_link_game_to_game_with_checksum_requires_child_game_exists(self):
        self.dao.save_game_dict("parent_game", "Parent Game")
        self.dao.save_game_checksum(
            "parent_game",
            "abc123def456",
            "SHA256",
            16 * 1024 * 1024,
            None,
            None,
        )

        with self.assertRaises(Exception):
            self.dao.link_game_to_game_with_checksum("alias_game", "parent_game")

    def _get_overall_time_for_game(self, game_id: str):
        return list(
            filter(lambda x: x.game_id == game_id, self.dao.fetch_overall_playtime())
        )[0].time
